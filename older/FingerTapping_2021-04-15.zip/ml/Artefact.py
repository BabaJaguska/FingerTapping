class Artefact:
    def __init__(self, name, description, values, dict_values, result):
        self.name = name
        self.description = description
        self.values = values
        self.dict_values = dict_values
        self.result = result
