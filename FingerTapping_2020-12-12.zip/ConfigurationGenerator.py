import numpy as np

import Parameters


def create_configurations(configuration_type):
    configurations = None
    if configuration_type == 'random_attr': configurations = create_configurations_random_attr(
        cnt=Parameters.number_of_configurations)
    if configuration_type == 'one_attr': configurations = create_configurations_one_attr(
        Parameters.one_attr_name, Parameters.one_attr_start, Parameters.one_attr_end,
        Parameters.one_attr_step)
    return configurations


def create_configurations_random_attr(cnt, attributes_values=Parameters.attribute_range_values, add_default=1):
    result = []

    while len(result) <= cnt:
        val = {}
        for attribute in attributes_values:
            attribute_name = attribute[0]
            # def_val = val[1]
            min_val = attribute[2]
            max_val = attribute[3]
            new_val = np.random.randint(min_val, max_val + 1)
            val[attribute_name] = new_val

        result.append(val)

    if add_default == 1:
        val = {}
        for attribute in attributes_values:
            attribute_name = attribute[0]
            def_val = attribute[1]
            val[attribute_name] = def_val
        result.append(val)
    return result


def create_configurations_one_attr(name, min_value, max_value, step,
                                   attributes_values=Parameters.attribute_default_values):
    result = []

    x = min_value
    while x <= max_value:
        val = {}
        for attribute in attributes_values:
            attribute_name = attribute[0]
            def_val = attribute[1]
            val[attribute_name] = def_val
        val[name] = x
        x = x + step
        result.append(val)

    return result


def to_string(configuration):
    keys = configuration.keys()
    keys = [x for x in keys]
    keys.sort()
    result = ''
    for key in keys:
        result = result + str(configuration[key]) + ' '

    if len(result) > 0:
        result = result[0:-1]
    return result


def to_string_keys(configuration):
    keys = configuration.keys()
    keys = [x for x in keys]
    keys.sort()
    result = ''
    for key in keys:
        result = result + str(key) + ' '

    if len(result) > 0:
        result = result[0:-1]
    return result
