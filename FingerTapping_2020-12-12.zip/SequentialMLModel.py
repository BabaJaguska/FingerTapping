import MachineLearningModel
from ConfigurableMLModelTopology import ConfigurableMLModelTopology


class SequentialMLModelTopology(ConfigurableMLModelTopology):
    def __init__(self, configuration):
        super().__init__(configuration)

        self.init_operation = MachineLearningModel.CNNSequentialModel
        self.fit_operation = MachineLearningModel.fit_model
        self.callbacks = MachineLearningModel.def_callbacks3

        self.optimizer = MachineLearningModel.get_optimizer1
        self.compile_model = MachineLearningModel.compile_model

        self.string_formatter = 'CNNSequentialMLModel [{} {}]'
        self.model_name = 'CNNSequentialFilters' + str(self.initialFilters) + 'Kernels' + str(self.kernel_size)
        return

    def __str__(self):
        result = self.string_formatter.format(self.initialFilters, self.kernel_size)
        return result
