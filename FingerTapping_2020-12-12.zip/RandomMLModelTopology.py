import time

import MachineLearningModel
from ConfigurableMLModelTopology import ConfigurableMLModelTopology


class RandomMLModelTopology(ConfigurableMLModelTopology):
    def __init__(self, configuration):
        super().__init__(configuration)

        self.init_operation = MachineLearningModel.CNNRandomModel
        self.fit_operation = MachineLearningModel.fit_model
        self.callbacks = MachineLearningModel.def_callbacks1

        self.optimizer = MachineLearningModel.get_optimizer1
        self.compile_model = MachineLearningModel.compile_model

        tm = time.gmtime()
        self.string_formatter = 'CNNRandomLModel{}.{}.{}.{}.{}'.format(tm[0], tm[1], tm[2], tm[3] + 1, tm[4])
        self.model_name = 'CNNRandom{}.{}.{}.{}.{}'.format(tm[0], tm[1], tm[2], tm[3] + 1, tm[4])
        return

    def __str__(self):
        result = self.string_formatter

        # TODO treba dodati da se ispisuje nesto o modelu jer se ne yna koji je random koriscen
        return result
