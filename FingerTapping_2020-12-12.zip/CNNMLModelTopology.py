import MachineLearningModel
from ConfigurableMLModelTopology import ConfigurableMLModelTopology


class CNNMLModelTopology(ConfigurableMLModelTopology):
    def __init__(self, configuration):
        super().__init__(configuration)

        self.model = None
        self.init_operation = MachineLearningModel.CNNModel
        self.fit_operation = MachineLearningModel.fit_model
        self.callbacks = MachineLearningModel.def_callbacks1

        self.optimizer = MachineLearningModel.get_optimizer1
        self.compile_model = MachineLearningModel.compile_model

        self.string_formatter = 'CNNMLModel [{}]'
        self.model_name = 'CNNShuffled' + str(self.batch_size) + 'Batch' + str(
            self.nConvLayers) + 'ConvLayers' + str(self.kernel_size) + 'KERNEL' + str(
            self.nUnits) + 'DenseUnits' + str(self.initialFilters) + 'initFilt'

        return
