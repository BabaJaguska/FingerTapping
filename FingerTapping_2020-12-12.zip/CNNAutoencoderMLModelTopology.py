import MachineLearningModel
from MLModelTopology import examine_history
from ConfigurableMLModelTopology import ConfigurableMLModelTopology


class CNNAutoencoderMLModelTopology(ConfigurableMLModelTopology):
    def __init__(self, configuration):
        super().__init__(configuration)

        self.autoencoder = None
        self.encoder = None

        self.to_string_formatter = 'CNNAutoencoderMLModel [{}]'
        self.model_name = 'CNNShuffled' + str(self.batch_size) + 'Batch' + str(
            self.nConvLayers) + 'ConvLayers' + str(self.kernel_size) + 'KERNEL' + str(
            self.nUnits) + 'DenseUnits' + str(self.initialFilters) + 'initFilt'

        return

    def init_model(self, data):
        [self.autoencoder, self.encoder] = MachineLearningModel.CNNModelAutoencoder(data, self.nConvLayers,
                                                                                    self.kernel_size,
                                                                                    self.kernel_constraint, self.nUnits,
                                                                                    self.initialFilters)
        self.autoencoder.summary()
        self.autoencoder.compile(optimizer='adam',
                                 metrics=['accuracy'],
                                 loss='binary_crossentropy')
        self.model = self.autoencoder
        return

    def train(self, train_data, validation_data, epochs):
        # TODO ovo jos nije implementirano
        print('TRAINING...')
        history = MachineLearningModel.fit_modelA(self.autoencoder, self.get_name(), train_data, validation_data,
                                                  epochs,
                                                  self.batch_size)
        validation_accuracy, train_accuracy = examine_history(history.history)

        return history, train_accuracy, validation_accuracy

    def evaluate(self, test_data):
        actual = self.autoencoder.evaluate(test_data[0], test_data[1])
        test_accuracy = actual[1]

        confuse_matrix = self.calc_confusion_matrix(test_data)

        return confuse_matrix, test_accuracy
