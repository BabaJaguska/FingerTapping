import numpy as np

import Diagnosis
import Parameters
import Signal2Test
from Test import Test


def create_tests(signals, test_type=Parameters.test_type, number_of_tests=Parameters.number_of_tests,
                 start_time=Parameters.start_time, end_time=Parameters.end_time, train_percent=Parameters.train_percent,
                 test_percent=Parameters.test_percent):
    tests = None
    if test_type == 'create_simple_tests':
        tests = create_simple_tests(signals, number_of_tests, train_percent, test_percent)
    if test_type == 'create_mixed_tests':
        tests = create_mixed_tests(signals, number_of_tests, train_percent, test_percent)

    tests = crop_tests(tests, start_time, end_time)
    return tests


def create_simple_tests(signals, number_of_tests, train_percent, test_percent):
    tests = []
    for i in range(number_of_tests):
        train_data, test_data, validation_data = [], [], []

        for diagnosis in Diagnosis.get_diagnosis_names():
            extract_test_and_concatenate(signals, diagnosis, train_percent, test_percent, train_data, test_data,
                                         validation_data)

        np.random.shuffle(train_data)
        np.random.shuffle(test_data)
        np.random.shuffle(validation_data)
        test = Test(train_data=train_data,
                    test_data=test_data,
                    validation_data=validation_data)
        tests.append(test)

    return tests


def extract_test_and_concatenate(signals, diagnosis, train_percent, test_percent, train_data, test_data,
                                 validation_data):
    trds, teds, vads = extract_test(signals, diagnosis, train_percent, test_percent)
    for trd in trds:
        train_data.append(trd)
    for ted in teds:
        test_data.append(ted)
    for vad in vads:
        validation_data.append(vad)
    return


def extract_test(signals, diagnosis, train_percent, test_percent):
    candidates = [sig for i, sig in enumerate(signals) if sig.diagnosis == diagnosis]
    validation_percent = 1 - train_percent - test_percent
    train_data, test_data, validation_data = [], [], []
    # Split into train, test, val sets

    train_num = int(train_percent * len(candidates))
    test_num = int(test_percent * len(candidates))
    validation_num = int(validation_percent * len(candidates))

    while len(validation_data) <= validation_num:
        index = np.random.randint(0, len(candidates))
        initials = candidates[index].initials
        signals = [candidate for i, candidate in enumerate(candidates) if candidate.initials == initials]
        for signal in signals:
            validation_data.append(signal)
            candidates.remove(signal)

    while len(test_data) <= test_num:
        index = np.random.randint(0, len(candidates))
        initials = candidates[index].initials
        signals = [candidate for i, candidate in enumerate(candidates) if candidate.initials == initials]
        for signal in signals:
            test_data.append(signal)
            candidates.remove(signal)

    for signal in candidates:
        train_data.append(signal)

    return train_data, test_data, validation_data


def create_mixed_tests(signals, number_of_tests, train_percent, test_percent):
    tests = []
    for i in range(number_of_tests):
        test = create_mixed_test(signals, train_percent, test_percent)
        tests.append(test[0])

    return tests


def create_mixed_test(signals, train_percent, test_percent):  # TODO da li ispravno ovako praviti test?
    inds = []
    for diagnosis in Diagnosis.get_diagnosis_names():
        ind = [i for i, sig in enumerate(signals) if sig.diagnosis == diagnosis]
        inds.append([ind])

    # Split into train, test, val sets
    data_train = []
    data_test = []
    data_validation = []
    for DIAGind in inds:
        diag_train, diag_test, diag_val = split_one_diagnosis(signals, DIAGind[0], train_percent, test_percent)
        data_train = data_train + diag_train
        data_test = data_test + diag_test
        data_validation = data_validation + diag_val

    test = Test(train_data=data_train,
                test_data=data_test,
                validation_data=data_validation)
    return [test]


def split_one_diagnosis(signals, DIAGind, trainPercent, testPercent):
    # np.random.seed(12345) # TODO ako se ovo stavi uvek vraca istu raspodelu!!
    trainInd = np.random.choice(DIAGind, round(trainPercent * len(DIAGind)), replace=False)
    Xtrain = [signals[i] for i in trainInd]
    leftover = [i for i in DIAGind if i not in trainInd]

    testInd = np.random.choice(leftover, round(testPercent * len(DIAGind)), replace=False)
    Xtest = [signals[i] for i in testInd]
    leftover = [i for i in leftover if i not in testInd]

    Xval = [signals[i] for i in leftover]

    return Xtrain, Xtest, Xval


def crop_tests(tests, start_time=0, end_time=8):
    result = []
    for test in tests:
        test = crop_test(test, start_time, end_time)
        result.append(test)

    return result


def crop_test(test, stat_time, end_time):
    Xtrain, Ytrain = crop_and_reshape(test.train_data, stat_time, end_time)
    Xtest, Ytest = crop_and_reshape(test.test_data, stat_time, end_time)
    Xval, Yval = crop_and_reshape(test.validation_data, stat_time, end_time)
    test = Test(train_data=(Xtrain, Ytrain),
                test_data=(Xtest, Ytest),
                validation_data=(Xval, Yval))
    return test


def crop_and_reshape(signals, start, end):
    # converts signal into signal+diagnosis for the given interval

    X = []  # signals
    Y = []  # diagnoses

    for signal in signals:
        _x, _y = Signal2Test.convert(signal, start, end)
        X.append(_x)
        Y.append(_y)

    l1 = len(X)
    l2 = X[0].shape[0]
    l3 = X[0].shape[1]
    if len(X[0].shape) == 2:
        X = np.reshape(X, (l1, l2, l3))
    else:
        l4 = X[0].shape[2]
        X = np.reshape(X, (l1, l2, l3, l4))
    X = np.swapaxes(X, 1, 2)
    Y = np.reshape(Y, (l1, Parameters.number_of_results))
    print('Shape of X: ', X.shape)
    return X, Y
