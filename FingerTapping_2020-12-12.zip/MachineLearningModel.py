import time

import numpy as np
from keras import optimizers
from keras.callbacks import ModelCheckpoint, EarlyStopping, ReduceLROnPlateau
from keras.constraints import max_norm
from keras.layers import Activation, BatchNormalization, GlobalAveragePooling1D
from keras.layers import Input, Conv1D, Flatten, MaxPooling1D, Reshape, UpSampling1D
from keras.layers import LSTM, Dense, Dropout
from keras.models import Model, load_model
from keras.models import Sequential
from tensorflow import keras
from tensorflow.python.keras.models import Sequential

import Parameters


# =============================================================================
# MODEL TOPOLOGIES
# =============================================================================

# =============================================================================
# THE CNN MODEL TOPOLOGY
# =============================================================================

def CNNModel(train_data, nConvLayers, kernel_size, kernel_constraint, nUnits, initialFilters,
             dropout1=Parameters.dropout_rate1, dropout2=Parameters.dropout_rate2):
    shape = (train_data[0].shape[1:])
    input1 = Input(shape=shape)

    # convolutions
    x = input1
    MAXFILTERNUM = 128
    for i in range(0, nConvLayers):

        nFilters = MAXFILTERNUM if initialFilters * (2 ** (i)) > MAXFILTERNUM else initialFilters * (2 ** (i))
        # inside = 3 if i>1 else 2
        inside = 2
        # TODO zaki promenio k = 11 if i == 0 else kernel_size
        k = kernel_size
        for temp in range(0, inside):
            x = Conv1D(filters=nFilters,
                       kernel_size=k,
                       padding='same',
                       strides=1,
                       kernel_initializer='he_normal',
                       kernel_constraint=max_norm(kernel_constraint),
                       name='Conv1x{}x{}_{}_{}'.format(k, nFilters, i, temp))(x)

            x = Activation('relu', name='ReLu_{}_{}'.format(i, temp))(x)
            x = BatchNormalization(name='Batch_{}_{}'.format(i, temp))(x)

            x = MaxPooling1D((2), padding='same', name='MaxPooling1x2_{}_{}'.format(i, temp))(x)

    x = Dropout(dropout1)(x)

    # Fully connected
    x = Flatten()(x)

    x = Dense(nUnits,
              kernel_constraint=max_norm(1),
              kernel_initializer='he_normal')(x)
    x = Activation('relu', name='reLU_dense')(x)
    x = Dropout(dropout2)(x)

    x = Dense(Parameters.number_of_results)(x)
    x = Activation('softmax', name='Softmax')(x)

    model = Model(input1, x)
    return model


# =============================================================================
# SEQUENTIAL MODEL TOPOLOGY
# =============================================================================
def CNNSequentialModel(train_data, nConvLayers, kernel_size, kernel_constraint, nUnits, initialFilters,
                       dropout1=Parameters.dropout_rate1):
    shape = (train_data[0].shape[1:])

    model = Sequential()
    model.add(Conv1D(initialFilters, kernel_size, padding='same', activation='relu', input_shape=shape))
    model.add(Conv1D(initialFilters, kernel_size, padding='same', activation='relu'))
    model.add(MaxPooling1D(2))
    model.add(Conv1D(2 * initialFilters, kernel_size, padding='same', activation='relu'))
    model.add(Conv1D(2 * initialFilters, kernel_size, padding='same', activation='relu'))
    model.add(GlobalAveragePooling1D())
    model.add(Dropout(dropout1))
    model.add(Dense(Parameters.number_of_results, activation='softmax'))

    return model


# =============================================================================
# LSTM MODEL TOPOLOGY
# =============================================================================
def LSTMModel(train_data, nConvLayers, kernel_size, kernel_constraint, nUnits, initialFilters,
              dropout1=Parameters.dropout_rate1):
    shape = (train_data[0].shape[1:])

    # TODO unaprediti model
    model = Sequential()

    # Recurrent layer
    model.add(LSTM(units=kernel_size, input_shape=shape, return_sequences=False, dropout=0.1, recurrent_dropout=0.1))

    # Fully connected layer
    model.add(Dense(nUnits, activation='relu'))

    # Dropout for regularization
    model.add(Dropout(dropout1))

    # Output layer
    model.add(Dense(Parameters.number_of_results, activation='softmax'))

    return model


# =============================================================================
# RANDOM MODEL TOPOLOGY
# =============================================================================
def CNNRandomModel(train_data, layers, filter_size, kernel_constraint, nUnits, initialFilters,
                   dropout1=Parameters.dropout_rate1, dropout2=Parameters.dropout_rate2):
    shape = (train_data[0].shape[1:])
    input1 = Input(shape=shape)

    # convolutions
    x = input1
    filter_layer_num = 0
    max_filter_layer_num = 128
    conv_percent = 0.25
    activation_percent = 0.25
    normalization_percent = 0.25
    pooling_percent = 0.25

    for i in range(0, layers):

        num = np.random.random()
        if (num < conv_percent) or (i == 0):
            nFilters = max_filter_layer_num if initialFilters * (
                    2 ** filter_layer_num) > max_filter_layer_num else initialFilters * (2 ** filter_layer_num)
            x = Conv1D(filters=nFilters,
                       kernel_size=filter_size,
                       padding='same',
                       strides=1,
                       kernel_initializer='he_normal',
                       kernel_constraint=max_norm(kernel_constraint),
                       name='Conv1x{}x{}_{}'.format(filter_size, filter_layer_num, i))(x)
            filter_layer_num = filter_layer_num + 1
            continue
        if num < conv_percent + activation_percent:
            x = Activation('relu', name='ReLu_{}'.format(i))(x)
            continue

        if num < conv_percent + activation_percent + normalization_percent:
            x = BatchNormalization(name='Batch_{}'.format(i))(x)
            continue
        if num < conv_percent + activation_percent + normalization_percent + pooling_percent:
            x = MaxPooling1D(2, padding='same', name='MaxPooling1x2_{}'.format(i))(x)
        continue

    # EXIT layer
    x = Dropout(dropout1)(x)

    # Fully connected
    x = Flatten()(x)

    x = Dense(nUnits,
              kernel_constraint=max_norm(1),
              kernel_initializer='he_normal')(x)
    x = Activation('relu', name='reLU_dense')(x)
    x = Dropout(dropout2)(x)

    x = Dense(Parameters.number_of_results)(x)
    x = Activation('softmax', name='Softmax')(x)

    model = Model(input1, x)

    return model


# =============================================================================
# THE CNN AUTOENCODER MODEL TOPOLOGY
# =============================================================================

def CNNModelAutoencoder(inputShape, nConvLayers, kernel_size, kernel_constraint, initFilters, nUnits,
                        dropout1=Parameters.dropout_rate1, dropout2=Parameters.dropout_rate2): # TODO not tested
    input1 = Input(shape=inputShape)

    # convolutions
    x = input1
    MAXFILTERNUM = 128

    for i in range(0, nConvLayers):

        nFilters = MAXFILTERNUM if initFilters * 2 ** i > MAXFILTERNUM else initFilters * 2 ** i
        # inside = 3 if i>1 else 2
        inside = 2
        for temp in range(0, inside):
            x = Conv1D(filters=nFilters,
                       kernel_size=kernel_size,
                       padding='same',
                       strides=1,
                       kernel_initializer='he_normal',
                       kernel_constraint=max_norm(kernel_constraint),
                       name='Conv1x{}x{}_{}_{}'.format(kernel_size, nFilters, i, temp))(x)

            x = Activation('relu', name='ReLu_{}_{}'.format(i, temp))(x)
            x = BatchNormalization(name='Batch_{}_{}'.format(i, temp))(x)

            x = MaxPooling1D((2), padding='same', name='MaxPooling1x2_{}_{}'.format(i, temp))(x)

    x = Dropout(dropout1)(x)

    # Fully connected
    x = Flatten(name='flatWhite')(x)

    #    x = Dense(nUnits,
    #              kernel_constraint = max_norm(kernel_constraint),
    #              kernel_initializer = 'he_normal')(x)
    #    x = Activation('relu', name = 'reLU_dense')(x)
    #    x = Dropout(dropout2,name='FCstuffEncoded')(x)

    filtTemp = 128 if nConvLayers > 2 else (nConvLayers) * initFilters
    rShape = (int(np.ceil(inputShape[0] / (2 ** (2 * nConvLayers)))), filtTemp)
    #    print(rShape)
    #    x = Dense(int(np.ceil(inputShape[0]/(2**(2*nConvLayers))))*filtTemp,
    #              activation='relu',
    #              kernel_initializer='he_normal',
    #              name='denseDude')(x)
    x = Reshape(rShape)(x)
    # decoder

    for i in range(0, nConvLayers):

        nFilters = 128 if i < nConvLayers - 2 else initFilters * (nConvLayers - i)

        for temp in range(0, 2):
            x = Conv1D(filters=nFilters,
                       kernel_size=kernel_size,
                       padding='same',
                       strides=1,
                       kernel_initializer='he_normal',
                       kernel_constraint=max_norm(kernel_constraint))(x)

            x = Activation('relu')(x)
            x = BatchNormalization()(x)

            x = UpSampling1D(2)(x)

    x = Conv1D(kernel_size=1, strides=1, filters=6,
               padding='same',
               kernel_initializer='he_normal',
               kernel_constraint=max_norm(kernel_constraint))(x)
    x = Activation('sigmoid')(x)

    model = Model(input1, x)
    features = model.get_layer('flatWhite').output
    encoder = Model(input1, features)

    return model, encoder


# utilize initialization
def CNNModelFromAutoencoder(nUnits, dropoutRate=Parameters.dropout_rate1): # TODO not tested
    encoder_file_name = './results/encoderCEOshuffleRIGHT.h5'
    encoder = load_model(encoder_file_name)

    x = encoder.output
    x = Dense(nUnits, kernel_constraint=max_norm(1),
              kernel_initializer='he_normal',
              activation='relu')(x)
    x = Dropout(dropoutRate)(x)
    x = Dense(Parameters.number_of_results, activation='softmax')(x)

    model = Model(encoder.input, x)
    return model


# =============================================================================
# FITERS
# =============================================================================

def fit_model(model, model_name, def_callbacks, train_data, validation_data, epochs, batch_size):
    tic = time.time()

    # make file name
    tm = time.gmtime()
    weight_file = './results/{}.{}.{}.{}.{}.{}.h5'.format(model_name, tm[0], tm[1], tm[2], tm[3] + 1,
                                                          tm[4])

    # define callbacks
    callbacks = def_callbacks(weight_file)

    # fit model
    x = train_data[0]
    y = train_data[1]
    history = model.fit(x=x, y=y,
                        batch_size=batch_size,
                        epochs=epochs,
                        verbose=1,
                        callbacks=callbacks,
                        validation_data=validation_data,
                        shuffle=True)
    toc = time.time()
    print("Finished training in {} min ({} h)".format(round((toc - tic) / 60, 2), round((toc - tic) / 3600, 2)))

    # Save the weights
    # model.save_weights(str(modelName)+'.h5') # ???????

    return history


def fit_modelA(model, modelName, train_data, validation_data, epochs, batch_size):  # TODO not tested
    tic = time.time()

    # make file name
    tm = time.gmtime()
    weight_file = './results/{}.{}.{}.{}.{}.{}.h5'.format(modelName, tm[0], tm[1], tm[2], tm[3] + 1, tm[4])

    # define callbacks
    callbacks = def_callbacks2(weight_file)

    train_x = train_data[0]
    validation_x = validation_data[0]
    # FIT THE MODEL
    history = model.autoencoder.fit(train_x, train_x,  # nije greska oba puta se uzima isto
                                    epochs=epochs,
                                    batch_size=batch_size,
                                    callbacks=callbacks,
                                    validation_data=(validation_x, validation_x),  # XvalA,XvalA
                                    shuffle=True)

    model.autoencoder.load_weights(weight_file)
    for l1, l2 in zip(model.encoder.layers, model.autoencoder.layers[:27]):
        l1.set_weights(l2.get_weights())

    # Save the weights
    encoder_file_name = './results/encoderCEOshuffleRIGHT.h5'
    model.encoder.save(encoder_file_name)

    toc = time.time()
    print("Finished training in {} min ({} h)".format(round((toc - tic) / 60, 2), round((toc - tic) / 3600, 2)))

    return history


# =============================================================================
# CALLBACKS
# =============================================================================


def def_callbacks1(weight_file):
    checkpoint = ModelCheckpoint(weight_file,
                                 monitor='val_accuracy',
                                 verbose=1,
                                 save_best_only=False,
                                 save_weights_only=True,
                                 mode='max')
    early = EarlyStopping(monitor='val_loss',
                          patience=20,
                          verbose=1,
                          mode='min')
    #     def step_decay(epoch):
    #         initial_lrate = 0.001
    #         rate_drop = 0.25
    #         nEpochs = 5
    #         lrate = initial_lrate * math.pow(rate_drop, math.floor(epoch/nEpochs))
    #         return lrate

    #     lrate = LearningRateScheduler(step_decay, verbose = 1)
    lr_plateau = ReduceLROnPlateau(monitor='val_loss', factor=0.1,
                                   patience=8, min_lr=0.0000000001,
                                   verbose=1)

    return [checkpoint, early, lr_plateau]


def def_callbacks2(weight_file):
    checkpoint = ModelCheckpoint(weight_file,
                                 monitor='val_loss',
                                 verbose=1,
                                 save_best_only=False,
                                 save_weights_only=True,
                                 mode='min')
    early = EarlyStopping(monitor='val_loss',
                          patience=20,
                          verbose=1,
                          mode='min')
    #     def step_decay(epoch):
    #         initial_lrate = 0.001
    #         rate_drop = 0.25
    #         nEpochs = 5
    #         lrate = initial_lrate * math.pow(rate_drop, math.floor(epoch/nEpochs))
    #         return lrate

    #     lrate = LearningRateScheduler(step_decay, verbose = 1)
    lr_plateau = ReduceLROnPlateau(monitor='val_loss', factor=0.1,
                                   patience=8, min_lr=0.0000000001,
                                   verbose=1)

    return [checkpoint, early, lr_plateau]


def def_callbacks3(weight_file):
    callbacks = [
        keras.callbacks.ModelCheckpoint(
            filepath=weight_file,
            monitor='val_loss', save_best_only=True),
        keras.callbacks.EarlyStopping(monitor='val_loss',
                                      patience=20,
                                      verbose=1,
                                      mode='min')
    ]

    return callbacks


# =============================================================================
# OPTIMIZERS
# =============================================================================

def get_optimizer1():
    return optimizers.Adam(lr=0.001)


def get_optimizer2():
    return optimizers.SGD(lr=0.001, momentum=0.9, nesterov=True)


# =============================================================================
# COMPILERS
# =============================================================================

def compile_model(model, optimizer):
    model.compile(optimizer=optimizer,
                  loss='categorical_crossentropy',
                  metrics=['accuracy'])
    return
