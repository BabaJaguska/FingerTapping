from MLModelTopology import MLModelTopology, examine_history


class ConfigurableMLModelTopology(MLModelTopology):
    def __init__(self, configuration):
        super().__init__(configuration)

        self.kernel_size = configuration['kernelSize']
        self.nConvLayers = configuration['nConvLayers']
        self.batch_size = configuration['batchSize']
        self.kernel_constraint = configuration['constraint']
        self.nUnits = configuration['nDenseUnits']
        self.initialFilters = configuration['nInitialFilters']

        return

    def init_model(self, data):
        self.model = self.init_operation(data, self.nConvLayers, self.kernel_size,
                                         self.kernel_constraint, self.nUnits, self.initialFilters)
        self.model.summary()

        self.compile_model(self.model, self.optimizer())

        return

    def train(self, train_data, validation_data, epochs):
        print('TRAINING...')
        history = self.fit_operation(self.model, self.get_name(), self.callbacks, train_data, validation_data, epochs,
                                     self.batch_size)
        validation_accuracy, train_accuracy = examine_history(history.history)

        return history, train_accuracy, validation_accuracy

    def evaluate(self, test_data):
        actual = self.model.evaluate(test_data[0], test_data[1])
        test_accuracy = actual[1]

        confuse_matrix = self.calc_confusion_matrix(test_data)

        return confuse_matrix, test_accuracy

    def get_configuration(self):
        return self.configuration
