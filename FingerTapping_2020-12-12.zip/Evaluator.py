import numpy as np

import Parameters
import Result


def multiple_evaluations(tests, models, path=Parameters.default_results_path):
    results = []

    for model in models:
        # try:
        print(str(model))
        model_results = []
        for test in tests:
            res = single_evaluation(test, model, path)
            model_results.append(res)

        res = combine_model_results(model_results)
        results.append(res)

        res.save(path + Parameters.default_results_file)
        show_evaluation_results_info([res], plot=1)

        # except:
        #   print("An exception occurred", sys.exc_info()[0])

    return results


def single_evaluation(test, model, path,
                      number_of_tries_per_configurations=Parameters.number_of_tries_per_configurations,
                      epochs=Parameters.epochs):
    validation_accuracies = []
    train_accuracies = []
    test_accuracies = []
    histories = []
    cms = []

    train_data = test.train_data
    validation_data = test.validation_data
    test_data = test.test_data

    for i in range(number_of_tries_per_configurations):
        model.init_model(train_data)

        model.show_model_info()

        model.save(path)

        history, train_accuracy, validation_accuracy = model.train(train_data, validation_data, epochs)
        histories.append(history)
        train_accuracies.append(train_accuracy)
        validation_accuracies.append(validation_accuracy)

        Result.show_history(history.history, model.get_name(), plot=Parameters.show_all)

        confuse_matrix, test_accuracy = model.evaluate(test_data)
        cms.append(confuse_matrix)
        test_accuracies.append(test_accuracy)

        Result.show_confuse_matrix(confuse_matrix, str(model) + str(i), plot=Parameters.show_all)

    res = Result.Result(model=model,
                        configuration=model.get_configuration(),
                        history=histories,
                        train_accuracy=train_accuracies,
                        validation_accuracy=validation_accuracies,
                        test_accuracy=test_accuracies,
                        best_validation_accuracy=np.mean(validation_accuracies),
                        best_train_accuracy=np.mean(train_accuracies),
                        best_test_accuracy=np.mean(test_accuracies),
                        confMats=cms)
    return res


def combine_model_results(model_results):
    model = model_results[0].model
    configuration = model_results[0].configuration

    histories = []
    for configuration_result in model_results:
        for data in configuration_result.history:
            histories.append(data)

    train_accuracy = []
    for configuration_result in model_results:
        for data in configuration_result.train_accuracy:
            train_accuracy.append(data)

    validation_accuracy = []
    for configuration_result in model_results:
        for data in configuration_result.validation_accuracy:
            validation_accuracy.append(data)

    test_accuracy = []
    for configuration_result in model_results:
        for data in configuration_result.test_accuracy:
            test_accuracy.append(data)

    size = len(model_results[0].confMats[0])
    cms = np.zeros((size, size), dtype=int)
    for configuration_result in model_results:
        for cm in configuration_result.confMats:
            cms = cms + cm

    res = Result.Result(model=model,
                        configuration=configuration,
                        history=histories,
                        train_accuracy=train_accuracy,
                        validation_accuracy=validation_accuracy,
                        test_accuracy=test_accuracy,
                        best_validation_accuracy=np.max(validation_accuracy),
                        best_train_accuracy=np.max(train_accuracy),
                        best_test_accuracy=np.max(test_accuracy),
                        confMats=cms)

    return res


def show_evaluation_results_info(results, plot=1):
    print('RESULTS:')
    Result.show_max_accuracy(results, plot)

    for res in results:
        print(str(res))

    # plot

    return
