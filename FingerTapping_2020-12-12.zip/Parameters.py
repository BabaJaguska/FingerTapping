import Diagnosis

# =============================================================================
# CONVERSIONS
# =============================================================================

covert_type = 'convert_values'
# covert_type = 'convert_spherical'
# covert_type = 'convert_amplitude'
# covert_type = 'convert_spectrogram'
# covert_type = 'convert_values_scaled'
# covert_type = 'convert_spherical_scaled'
# covert_type = 'convert_amplitude_scaled'

# Split into train, test, val sets
train_percent = 0.7
test_percent = 0.2
validation_percent = 0.1

start_time = 0
end_time = 8
def_signal_val = 0

# =============================================================================
# CONFIGURATIONS
# =============================================================================

# configuration_type = 'random_attr'
number_of_configurations = 20
attribute_range_values = (('nConvLayers', 3, 3, 3),
                          ('kernelSize', 11, 5, 50),
                          ('batchSize', 16, 10, 50),
                          ('constraint', 3, 3, 10),
                          ('nDenseUnits', 64, 32, 80),
                          ('nInitialFilters', 32, 16, 48))

configuration_type = 'one_attr'
attribute_default_values = (('nConvLayers', 3),
                            ('kernelSize', 11),
                            ('batchSize', 16),
                            ('constraint', 3),
                            ('nDenseUnits', 64),
                            ('nInitialFilters', 32))
one_attr_name = 'kernelSize'
one_attr_start = 11
one_attr_end = 11
one_attr_step = 1

# =============================================================================
# MODEL TOPOLOGIES
# =============================================================================

model_topology_type = 'CNNMLModel'
# model_topology_type = 'CNNSequentialMLModel'
# model_topology_type = 'CNNRandomMLModel'
# model_topology_type = 'LSTMMLModel'

dropout_rate1 = 0.6
dropout_rate2 = 0.7

# =============================================================================
# EVALUATION
# =============================================================================

number_of_tries_per_configurations = 5
epochs = 200

# =============================================================================
# TESTS
# =============================================================================

test_type = 'create_simple_tests'
# test_type = 'create_mixed_tests'

number_of_tests = 5

# =============================================================================
# MISCELLANEOUS
# =============================================================================

default_results_path = './results/'
default_root_path = './raw data/'
default_results_file = 'result.txt'
splits_file = './allSplits.txt'

show_all = 1

number_of_results = Diagnosis.get_diagnosis_number()

# =============================================================================
# OLD - NOT IN USE
# =============================================================================

root = 'd:/Users/zaki/kod/python/FingerTapping/raw data/'
path = 'd:/Users/zaki/kod/python/FingerTapping/'
