import Signal
import Diagnosis


class Test:
    def __init__(self, train_data, validation_data, test_data):
        self.train_data = train_data
        self.validation_data = validation_data
        self.test_data = test_data

        return

    def __str__(self):
        result = 'sizes: train:{}, validation:{}, test{}'.format(len(self.train_data), len(self.validation_data),
                                                                 len(self.test_data))
        return result

    def __repr__(self):
        return str(self)


def show_tests_info(tests, signals, plot=1):
    # plot
    if plot == 1:
        Signal.plot_class_distribution(signals)

    for test in tests:
        show_test_info(test, plot)
    return


def show_test_info(test, plot=1):
    train_data = test.train_data
    validation_data = test.validation_data
    test_data = test.test_data

    print(len(train_data[0]), len(validation_data[0]), len(test_data[0]))

    show_class_distribution(train_data, 'Train', plot)
    show_class_distribution(validation_data, 'Validation', plot)
    show_class_distribution(test_data, 'Test', plot)
    return


def show_class_distribution(test, test_type, plot=1):
    diagnoses = test[1]
    Diagnosis.show_class_distribution(diagnoses, test_type, plot)

    return
