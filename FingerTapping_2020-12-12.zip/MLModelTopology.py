import sys

import numpy as np
from sklearn.metrics import confusion_matrix

import ConfigurationGenerator
from Diagnosis import get_diagnosis_names_plot


class MLModelTopology:
    def __init__(self, configuration):
        self.configuration = configuration

        self.model = None
        self.init_operation = None
        self.fit_operation = None
        self.callbacks = None
        self.optimizer = None
        self.compile_model = None

        self.string_formatter = 'MLModel [{}]'
        self.model_name = 'MLModel'

        return

    def init_model(self, data):
        pass

    def train(self, train_data, validation_data, epochs):
        pass

    def evaluate(self, test_data):
        pass

    def get_name(self):
        return self.model_name

    def show_model_info(self, plot=1):
        self.model.summary()
        return

    def save(self, path, extension='CEO.h5'):
        name = path + self.get_name() + extension
        try:
            self.model.save(name)
        except:
            print("An exception occurred during saving:" + name, sys.exc_info())
            # TODO javlja se ova greska OSError: Unable to create link (name already exists)
        return

    def calc_confusion_matrix(self, test_data):
        Xtest = test_data[0]
        Ytest = test_data[1]
        p, a = [], []
        for X, Y in zip(Xtest, Ytest):
            temp = predict_signal(X, Y, self.model, verbose=0)
            p.append(temp['Predicted'])
            a.append(temp['Actual'])

        confMat = confusion_matrix(a, p)
        print(confMat)

        return confMat

    def __str__(self):
        result = self.string_formatter.format(ConfigurationGenerator.to_string(self.configuration))
        return result

    def __repr__(self):
        return str(self)


def examine_history(history):
    return max(history['val_accuracy']), max(history['accuracy'])


def predict_signal(signalX, signalY, model, verbose=1):
    signalX = np.expand_dims(signalX, axis=0)
    prediction = model.predict(signalX)
    prediction = prediction[0]
    prediction = np.round(np.float32(prediction), 2)

    d = get_diagnosis_names_plot()

    actualDiagnosis = d[np.argmax(signalY)]
    predictedDiagnosis = d[np.argmax(prediction)]

    if verbose:
        print('predictedDiagnosis: ', predictedDiagnosis)
        print('actualDiagnosis: ', actualDiagnosis)

        diagnosis = 'Certainty: \n'
        for i in range(len(prediction)):
            name = d[i]
            diagnosis = diagnosis + name + ': {} \n'.format(prediction[i])
        print(diagnosis)
        print('#################################################')

    return {"Predicted": predictedDiagnosis, "Actual": actualDiagnosis}


def show_models_info(models, plot=1):
    # calc

    # #print
    print('MODELS: {}'.format(len(models)))

    # plot
    return
