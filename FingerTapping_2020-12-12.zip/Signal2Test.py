import numpy as np

import Diagnosis
import Parameters


def convert(signal, start, end, def_val=0, covert_type=Parameters.covert_type):
    result = None
    if covert_type == 'convert_values': result = convert_values(signal, start, end, def_val)
    if covert_type == 'convert_spherical': result = convert_spherical(signal, start, end, def_val)
    if covert_type == 'convert_amplitude':  result = convert_amplitude(signal, start, end, def_val)
    if covert_type == 'convert_spectrogram':  result = convert_spectrogram(signal, start, end, def_val)
    if covert_type == 'convert_values_scaled': result = convert_values_scaled(signal, start, end, def_val)
    if covert_type == 'convert_spherical_scaled': result = convert_spherical_scaled(signal, start, end, def_val)
    if covert_type == 'convert_amplitude_scaled':  result = convert_amplitude_scaled(signal, start, end, def_val)

    return result


def convert_values(signal, start, end, def_val=0):
    result = adjust(signal, (signal.gyro1x, signal.gyro1y, signal.gyro1z, signal.gyro1x, signal.gyro1y, signal.gyro1z),
                    start, end, def_val)
    return result


def convert_values_scaled(signal, start, end, def_val=0):
    gyro1x, gyro1y, gyro1z = signal.gyro1x, signal.gyro1y, signal.gyro1z
    max_1 = max(signal.gyro1Vec)
    gyro1x, gyro1y, gyro1z = gyro1x / max_1, gyro1y / max_1, gyro1z / max_1
    gyro2x, gyro2y, gyro2z = signal.gyro2x, signal.gyro2y, signal.gyro2z
    max_2 = max(signal.gyro2Vec)
    gyro2x, gyro2y, gyro2z = gyro2x / max_2, gyro2y / max_2, gyro2z / max_2

    result = adjust(signal, (gyro1x, gyro1y, gyro1z, gyro2x, gyro2y, gyro2z), start, end, def_val)
    return result


def convert_spherical(signal, start, end, def_val=0):
    result = adjust(signal, signal.transform_spherical(), start, end, def_val)

    return result


def convert_spherical_scaled(signal, start, end, def_val=0):
    r1, phi1, theta1, r2, phi2, theta2 = signal.transform_spherical()
    max_1 = max(r1)
    r1 = r1 / max_1
    max_2 = max(r2)
    r2 = r2 / max_2
    result = adjust(signal, (r1, phi1, theta1, r2, phi2, theta2), start, end, def_val)

    return result


def convert_amplitude(signal, start, end, def_val=0):
    result = adjust(signal, (signal.gyro1Vec, signal.gyro2Vec), start, end, def_val)
    return result


def convert_amplitude_scaled(signal, start, end, def_val=0):
    values_1 = signal.gyro1Vec
    max_1 = max(signal.gyro1Vec)
    values_1 = values_1 / max_1
    values_2 = signal.gyro2Vec
    max_2 = max(signal.gyro2Vec)
    values_2 = values_2 / max_2
    result = adjust(signal, (values_1, values_2), start, end, def_val)
    return result


def convert_spectrogram(signal, start, end, def_val=0):
    result = adjust(signal, signal.spectrogram_i, start, end, def_val)  # TODO ne radi ako se uzmu obe ose!
    return result


def adjust(signal, data, start, end, def_val=Parameters.def_signal_val):
    start_index = int(start * signal.sampling_rate)
    end_index = int(end * signal.sampling_rate)

    result = []
    for d in data:
        crop = d[start_index:end_index]

        l1 = len(crop)
        s = end_index - start_index - l1
        if s > 0:
            line = np.full(crop[0].shape, def_val)
            for i in range(s):
                crop = np.append(crop, [line], axis=0)

        result.append([crop])
    crops = np.concatenate(result)
    diagnosis = Diagnosis.encode_diagnosis(signal.diagnosis)
    return crops, diagnosis
