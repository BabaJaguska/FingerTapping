import itertools

import matplotlib.pyplot as plt
import numpy as np

import ConfigurationGenerator
import Diagnosis
import Parameters


class Result:
    def __init__(self, model, configuration, history,
                 test_accuracy, train_accuracy, validation_accuracy,
                 best_test_accuracy, best_train_accuracy, best_validation_accuracy,
                 confMats):

        self.model = model
        self.configuration = configuration
        self.history = history
        self.test_accuracy = test_accuracy
        self.train_accuracy = train_accuracy
        self.validation_accuracy = validation_accuracy
        self.best_test_accuracy = best_test_accuracy
        self.best_train_accuracy = best_train_accuracy
        self.best_validation_accuracy = best_validation_accuracy
        self.confMats = confMats

        return

    def __str__(self):
        try:
            res = '----------\n{}\n{}\n{}\n{}\n{}\t{}\t{}\n{}\n----------\n'.format(
                ConfigurationGenerator.to_string(self.configuration),
                self.train_accuracy,
                self.validation_accuracy,
                self.test_accuracy,
                self.best_train_accuracy,
                self.best_validation_accuracy,
                self.best_test_accuracy,
                self.confMats)
        except:
            res = ''
        return res

    def __repr__(self):
        return str(self)

    def save(self, file_name):
        with open(file_name, 'a') as file:
            file.write(str(self.model))
            file.write(str(self))
            file.write('\n--------------------\n')
            file.close()
        return


def show_confuse_matrix(cm, comment='', plot=1):
    # plot
    if plot == 1:
        plot_confuse_matrix(cm, comment)
    return


def plot_confuse_matrix(cm, comment=''):
    confMatPerc = calc_confuse_matrix_percent(cm)

    plt.figure(figsize=(10, 10))
    plt.imshow(confMatPerc)
    plt.colorbar()
    for i, j in itertools.product(range(Parameters.number_of_results), range(Parameters.number_of_results)):
        plt.text(i, j, '{}%\n({})'.format(round(confMatPerc[j, i], 2), cm[j, i], 'd'),
                 horizontalalignment='center',
                 color='white' if confMatPerc[j, i] < 60 else 'black',
                 size=15)
    tick_marks = np.arange(Parameters.number_of_results)
    classes = Diagnosis.get_diagnosis_names()
    plt.xticks(tick_marks, classes, rotation=45, size=15)
    plt.yticks(tick_marks, classes, size=15)
    plt.ylabel('True label', size=15)
    plt.xlabel('\nPredicted label', size=15)
    plt.style.use(['tableau-colorblind10'])
    plt.title('Confusion matrix: {}\n'.format(comment), size=17)
    plt.show()
    return


def calc_confuse_matrix_percent(confMat):
    sumaPoRedovima = confMat.astype('float').sum(axis=1)
    confMatPerc = [gore / dole for gore, dole in zip(confMat, sumaPoRedovima)]
    confMatPerc = np.matrix(confMatPerc) * 100
    return confMatPerc


def show_history(history, model_name, plot=1):
    # print
    print("Max val accuracy: ", max(history['val_accuracy']))
    print("Max train accuracy: ", max(history['accuracy']))

    # plot
    if plot == 1:
        # plot Accuracy over Epochs
        plt.plot(history['accuracy'])
        plt.plot(history['val_accuracy'])
        plt.xlabel('Epoch')
        plt.ylabel('Accuracy')
        plt.legend(['Train Acc', 'Val Acc'])
        plt.title('Accuracy for {} over epochs'.format(model_name))
        plt.show()

        # plot Loss over Epochs
        plt.plot(history['loss'])
        plt.plot(history['val_loss'])
        plt.xlabel('Epoch')
        plt.ylabel('Loss')
        plt.legend(['Train Loss', 'Val Loss'])
        plt.title('Loss for {} over epochs'.format(model_name))
        plt.show()

    return


def show_max_accuracy(results, plot=1):
    max_accuracy = 0
    max_result = []
    cm = []

    for result in results:
        tests = result.best_test_accuracy
        accuracy = np.max(tests)
        if max_accuracy < accuracy:
            max_result = result
            max_accuracy = accuracy
            cm = result.confMats

    print('\n---MAX TEST ACCURACY:{}---\n'.format(max_accuracy))
    print(str(max_result))
    print('\n-------------\n')

    # plot
    if plot == 1:
        plot_confuse_matrix(cm, 'Overall ' + str(max_result.model))

    return
